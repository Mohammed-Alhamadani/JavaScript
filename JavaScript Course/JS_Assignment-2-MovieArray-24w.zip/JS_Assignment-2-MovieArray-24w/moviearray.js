// declare and initialize 7 variables with 7 movie names.

let movie1 = "Brave heart";
let movie2 = "The keeper";
let movie3 = "The legend";
let movie4 = "Transporter";
let movie5 = "Home alone";
let movie6 = "Transformer";
let movie7 = "Spider man";

// Array to hold the variables & the top 7 movies list

let top7Movies = [movie1, movie2, movie3, movie4, movie5, movie6, movie7];

// the user asked "Which top 7 movie would you like? and "Pick a number: 1-7"

let userInput = window.prompt("Pick a number: 1-7 ");

let isValidUserInput = false;

// Validation  the user input.
userInput = parseInt(userInput);

// the logic here if the input not a number or greater than 7 or smaller than 1 will notify the user for "Please enter a number between 1 and 7!"

if (userInput > 0 && userInput <= top7Movies.length) {
    alert(
        `Number ${userInput} on the list is with ${userInput} being the movie's position on the top 7, ${top7Movies[userInput - 1]}`
        );

    isValidUserInput = true;


} else {
    isValidUserInput = false;

}



// Output messages to the console with a loop that lists all of the movies with their number.

for (let i = 0; i < top7Movies.length; i++) {
    console.log(`Movie ${(i+1)}:${top7Movies[i]}`);

}

// Function to ReAsk the user to input a number between 1 and 7

function reAsk() {
    userInput = window.prompt("Please enter a number between 1 and 7!");
    userInput = parseInt(userInput);
    if (userInput > 0 && userInput <= top7Movies.length) {
        alert(
            `Number ${userInput} on the list is with ${userInput} being the movie's position on the top 7, ${top7Movies[userInput - 1]}`
            );
        isValidUserInput = true;

    } else {
        isValidUserInput = false;

    }



}

// Flag to use it when the condition didn't pass

while (isValidUserInput == false) {
    reAsk();
}