//LAB 3 - ARRAYS & LOOPS - PART 1


//ARRAY OF FRUITS


//OUTPUT ONE FRUIT FROM THE ARRAY IN POPUP BOX


var fruits = ['orange', 'apple', 'banana', 'kiwi', 'peach'];


alert(fruits[3]);