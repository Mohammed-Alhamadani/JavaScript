//LAB 3 - ARRAYS & LOOPS - PART 3

//PART 3 - SHOPPING CART SHIPPING
//==== VARIABLES ========


//==== LOGIC ========
//CHECK FOR ITEMS UNTIL THRESHOLD IS MET.

	//GET ITEM COST FROM USER
	
	
	//CONVERT USER INPUT TO A NUMBER
	
	
	//ADD ITEM COST TO RUNNING TOTAL VARIABLE
	
	
	//PUSH ITEM COST TO CART ARRAY
	
	
	


//SEND POPUP MESSAGE TO USER


//SEND OUTPUT TO CONSOLE

var cart = [];
var input;
var sum=0;

	
	while(sum < 35) {

		input = window.prompt("Please Enter The Value ");
		input = parseInt(input);
		sum += input;
		cart.push(input);
		
		console.log(cart);
		console.log(sum);
		console.log("Item prices: " + cart.join(" | "));



	}

alert("Your shipping for this order will be free!")
alert("The total value of the purchases "+sum+"$")



