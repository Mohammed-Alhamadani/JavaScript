//LAB 3 - ARRAYS & LOOPS - PART 2


//PM TEAM MEMBER ARRAY


//OUTPUT TEAM ARRAY TO JS CONSOLE


//REMOVE LAST MEMBER


//ADD SEAN TO FRONT OF ARRAY


//REARRANGE THE ARRAY ALPHABETICALLY


//OUTPUT REQUIRED MESSAGE TO JS CONSOLE


//LOOP THROUGH ARRAY TO OUTPUT TEAM MEMBERS/NUMBERS TO JS CONSOLE

var ourTeam=["mohammed","mike","andi","mark","saif"];

console.log(ourTeam)

ourTeam.pop();
console.log(ourTeam)

ourTeam.unshift("sean");
console.log(ourTeam)

ourTeam.sort();
console.log(ourTeam)

console.log("We have "+ ourTeam.length+" people in our group.")


for (var i = 0; i < ourTeam.length; i++){
    console.log(ourTeam[i]+" is number "+(i+1))
}