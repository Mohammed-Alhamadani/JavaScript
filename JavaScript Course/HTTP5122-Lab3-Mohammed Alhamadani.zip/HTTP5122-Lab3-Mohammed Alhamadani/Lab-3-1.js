//LAB 3 - ARRAYS & LOOPS - PART 1

// Create a JavaScript array of fruit with 5 fruits in it.


var fruits = ['orange', 'apple', 'banana', 'kiwi', 'peach'];

// Have an alert box output one of the fruits from the array.

alert(fruits[2]);